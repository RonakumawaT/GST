package com.example.RK8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Gste1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
